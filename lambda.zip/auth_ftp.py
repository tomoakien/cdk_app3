def handler(event, context):
    print("Transfer FamilyのFTP認証を行う関数")
